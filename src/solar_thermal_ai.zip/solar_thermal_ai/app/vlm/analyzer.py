"""VLM 기반 결함 최종 판정기.

역할:
- YOLO + 열화상 통계가 '핫스팟 후보'를 내면, VLM이 RGB 크롭 + IR 크롭을 함께 보고:
  1) 실제 결함인지 / 그림자·반사·구름 등 false positive인지 판정
  2) 결함 클래스 확정 (bypass diode / PID / cell crack / ...)
  3) 심각도 + 조치사항 + root cause 근거 도출

백엔드는 교체 가능:
- AnthropicVLM (Claude 3.5/4 Sonnet) — 기본
- QwenVLM (on-prem Qwen2.5-VL) — 폐쇄망/보안 요구 환경
"""
from __future__ import annotations

import base64
import io
import json
import os
from abc import ABC, abstractmethod
from typing import Optional

import cv2
import numpy as np

from app.schemas.models import (
    DefectClass, HotspotDetection, PanelDetection, Severity, VLMVerdict,
)


SYSTEM_PROMPT = """You are a senior solar PV thermographer (Level 2 certified per IEC TS 62446-3).
You analyze paired RGB + thermal IR crops of solar panels to confirm or reject defect candidates
proposed by an upstream YOLO + thermal pipeline.

Your decisions are used by O&M crews to dispatch on-site inspection, so:
- Be conservative about confirming critical classes (bypass_diode, PID).
- Always check if the pattern could be explained by external shading, cloud edge,
  bird droppings, soiling, or reflection, rather than a real electrical defect.
- Distinguish cell-level crack (linear hotline) from busbar artifacts.
- If RGB clearly shows dust/leaves/bird droppings on the panel, classify as soiling
  even if thermal shows elevated ΔT.

Respond with STRICT JSON only — no prose, no markdown fences. Schema:
{
  "confirmed_class": "<one of: single_cell_hotspot | multi_cell_hotspot | bypass_diode_failure | potential_induced_degradation | soiling | cell_crack | junction_box_overheat | shading | unknown>",
  "is_actual_defect": <bool>,
  "severity": "<info|low|medium|high|critical>",
  "root_cause": "<1-2 sentence plausible root cause>",
  "recommended_action": "<1 sentence O&M action>",
  "confidence": <0.0-1.0>,
  "evidence_notes": "<what you saw in RGB vs IR that drove the decision>"
}"""


def _encode_image(bgr: np.ndarray, fmt: str = ".jpg", quality: int = 90) -> str:
    ok, buf = cv2.imencode(fmt, bgr, [cv2.IMWRITE_JPEG_QUALITY, quality])
    if not ok:
        raise RuntimeError("Image encode failed")
    return base64.b64encode(buf.tobytes()).decode("ascii")


def _crop_with_margin(img: np.ndarray, bbox, margin: float = 0.3) -> np.ndarray:
    h, w = img.shape[:2]
    cx = (bbox.x1 + bbox.x2) / 2
    cy = (bbox.y1 + bbox.y2) / 2
    bw = (bbox.x2 - bbox.x1) * (1 + margin)
    bh = (bbox.y2 - bbox.y1) * (1 + margin)
    x1 = max(0, int(cx - bw / 2))
    y1 = max(0, int(cy - bh / 2))
    x2 = min(w, int(cx + bw / 2))
    y2 = min(h, int(cy + bh / 2))
    return img[y1:y2, x1:x2].copy()


class VLMBackend(ABC):
    @abstractmethod
    def analyze(self, prompt_text: str, rgb_b64: str, ir_b64: str) -> dict: ...


class AnthropicVLM(VLMBackend):
    """Claude API를 통한 VLM 분석."""

    def __init__(self,
                 model: str = "claude-sonnet-4-5",
                 api_key: Optional[str] = None,
                 max_tokens: int = 800):
        try:
            import anthropic  # type: ignore
        except ImportError as e:
            raise RuntimeError("anthropic SDK not installed") from e
        self.client = anthropic.Anthropic(api_key=api_key or os.environ.get("ANTHROPIC_API_KEY"))
        self.model = model
        self.max_tokens = max_tokens

    def analyze(self, prompt_text: str, rgb_b64: str, ir_b64: str) -> dict:
        resp = self.client.messages.create(
            model=self.model,
            max_tokens=self.max_tokens,
            system=SYSTEM_PROMPT,
            messages=[{
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt_text},
                    {"type": "text", "text": "RGB crop:"},
                    {"type": "image",
                     "source": {"type": "base64", "media_type": "image/jpeg", "data": rgb_b64}},
                    {"type": "text", "text": "Thermal IR crop (Inferno colormap, higher = hotter):"},
                    {"type": "image",
                     "source": {"type": "base64", "media_type": "image/jpeg", "data": ir_b64}},
                ],
            }],
        )
        text = "".join(block.text for block in resp.content if getattr(block, "type", "") == "text")
        return _safe_json_parse(text)


class QwenVLM(VLMBackend):
    """On-prem Qwen2.5-VL (vLLM OpenAI-compatible endpoint)."""

    def __init__(self, base_url: str, model: str = "Qwen/Qwen2.5-VL-7B-Instruct",
                 api_key: str = "EMPTY"):
        from openai import OpenAI  # type: ignore
        self.client = OpenAI(base_url=base_url, api_key=api_key)
        self.model = model

    def analyze(self, prompt_text: str, rgb_b64: str, ir_b64: str) -> dict:
        resp = self.client.chat.completions.create(
            model=self.model,
            max_tokens=800,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": [
                    {"type": "text", "text": prompt_text},
                    {"type": "image_url",
                     "image_url": {"url": f"data:image/jpeg;base64,{rgb_b64}"}},
                    {"type": "image_url",
                     "image_url": {"url": f"data:image/jpeg;base64,{ir_b64}"}},
                ]},
            ],
        )
        return _safe_json_parse(resp.choices[0].message.content or "")


def _safe_json_parse(text: str) -> dict:
    text = text.strip()
    # 모델이 간혹 ```json ... ``` 래핑 — 안전하게 제거
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # 중괄호 영역만 추출 시도
        start = text.find("{")
        end = text.rfind("}")
        if start >= 0 and end > start:
            try:
                return json.loads(text[start:end + 1])
            except json.JSONDecodeError:
                pass
        return {}


class VLMAnalyzer:
    """Pipeline에서 호출하는 파사드."""

    def __init__(self, backend: VLMBackend):
        self.backend = backend

    def analyze_hotspot(self,
                        rgb_registered: np.ndarray,   # IR 좌표계에 정합된 RGB
                        ir_display_bgr: np.ndarray,   # 시각화된 IR (BGR)
                        hotspot: HotspotDetection,
                        panel: Optional[PanelDetection]) -> VLMVerdict:
        rgb_crop = _crop_with_margin(rgb_registered, hotspot.bbox_ir, margin=0.4)
        ir_crop = _crop_with_margin(ir_display_bgr, hotspot.bbox_ir, margin=0.4)

        rgb_b64 = _encode_image(rgb_crop)
        ir_b64 = _encode_image(ir_crop)

        prompt = _build_prompt(hotspot, panel)
        try:
            parsed = self.backend.analyze(prompt, rgb_b64, ir_b64)
        except Exception as e:  # 네트워크/파싱 실패 — 안전한 기본 verdict
            return VLMVerdict(
                confirmed_class=hotspot.candidate_class,
                is_actual_defect=hotspot.thermal.delta_t_c >= 10,
                severity=Severity.MEDIUM,
                root_cause=f"VLM analysis failed: {type(e).__name__}",
                recommended_action="On-site visual inspection recommended.",
                confidence=0.3,
                evidence_notes="VLM fallback to thermal-only decision.",
            )
        return _parsed_to_verdict(parsed, hotspot)


def _build_prompt(hs: HotspotDetection, panel: Optional[PanelDetection]) -> str:
    t = hs.thermal
    panel_info = ""
    if panel is not None:
        panel_info = f"Panel reference median temp: {panel.bbox_ir} ROI.\n"
    return (
        f"Upstream candidate class: {hs.candidate_class.value}\n"
        f"IEC class: {hs.iec_class}\n"
        f"Thermal stats — ΔT={t.delta_t_c:.1f}°C, hotspot p95={t.t_p95_c:.1f}°C, "
        f"panel median={t.panel_ref_c:.1f}°C, max={t.t_max_c:.1f}°C\n"
        f"{panel_info}\n"
        "Confirm or reject the defect using BOTH the RGB and thermal crops. "
        "If RGB shows shading from external objects, birds, soiling, or reflections "
        "that fully explain the thermal anomaly, set is_actual_defect=false and "
        "choose the appropriate non-defect class (shading/soiling)."
    )


def _parsed_to_verdict(p: dict, hs: HotspotDetection) -> VLMVerdict:
    def _safe_enum(value: str, enum_cls, default):
        try:
            return enum_cls(value)
        except (ValueError, TypeError):
            return default

    return VLMVerdict(
        confirmed_class=_safe_enum(p.get("confirmed_class", ""),
                                   DefectClass, hs.candidate_class),
        is_actual_defect=bool(p.get("is_actual_defect", False)),
        severity=_safe_enum(p.get("severity", "medium"), Severity, Severity.MEDIUM),
        root_cause=str(p.get("root_cause", ""))[:500],
        recommended_action=str(p.get("recommended_action", ""))[:500],
        confidence=float(p.get("confidence", 0.5)),
        evidence_notes=str(p.get("evidence_notes", ""))[:1000],
    )
