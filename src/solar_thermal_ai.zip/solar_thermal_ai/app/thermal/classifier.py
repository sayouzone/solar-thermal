"""IEC TS 62446-3 기반 열화상 결함 1차 분류.

VLM에 넘기기 전 YOLO + thermal stats만으로 후보 결함 클래스를 결정.
VLM은 이 후보를 검증/보정하는 역할.
"""
from __future__ import annotations

from typing import Optional

import numpy as np

from app.schemas.models import (
    BBox, DefectClass, HotspotDetection, PanelDetection, ThermalStats,
)


# IEC TS 62446-3 참조 — 운영 환경에 맞춰 config 파일로 빼는 것을 권장
THRESHOLDS = {
    "single_cell_hs_dt": 20.0,
    "multi_cell_hs_dt": 10.0,
    "bypass_diode_dt": 5.0,
    "pid_bottom_dt": 3.0,
    "soiling_dt": -2.0,
    "junction_box_dt": 15.0,
    "cell_crack_dt": 5.0,
}


def _iec_class(delta_t: float) -> Optional[str]:
    if delta_t >= 20:
        return "Class_A"   # 즉시 조치
    if delta_t >= 10:
        return "Class_B"   # 모니터링
    if delta_t >= 3:
        return "Class_C"   # 기록
    return None


def _pattern_from_shape(bbox: BBox, panel_bbox: BBox) -> str:
    """핫스팟 bbox 형태로 패턴 추정."""
    w = bbox.x2 - bbox.x1
    h = bbox.y2 - bbox.y1
    panel_w = panel_bbox.x2 - panel_bbox.x1
    panel_h = panel_bbox.y2 - panel_bbox.y1

    aspect = max(w, h) / max(1e-3, min(w, h))
    panel_fill = (w * h) / max(1e-3, panel_w * panel_h)

    # 핫스팟이 패널의 1/3 이상 → bypass diode 의심
    if panel_fill >= 0.28:
        return "string_pattern"
    # 세장비 큼 → crack 라인
    if aspect >= 4.0:
        return "linear_pattern"
    # 패널 하단 row — PID
    rel_center_y = ((bbox.y1 + bbox.y2) / 2 - panel_bbox.y1) / max(1e-3, panel_h)
    if rel_center_y > 0.75 and w / max(1e-3, panel_w) > 0.6:
        return "bottom_row_pattern"
    return "point_pattern"


def classify_hotspot(hotspot_bbox: BBox,
                     thermal: ThermalStats,
                     panel: PanelDetection) -> tuple[DefectClass, Optional[str]]:
    """YOLO + thermal stats만으로 후보 결함 클래스 결정.

    Returns: (candidate_class, iec_class)
    """
    dt = thermal.delta_t_c
    pattern = _pattern_from_shape(hotspot_bbox, panel.bbox_ir)

    # 1) 저온 이상 → soiling 후보 (VLM에서 RGB로 확정)
    if dt <= THRESHOLDS["soiling_dt"]:
        return DefectClass.SOILING, None

    # 2) 패턴 기반 분기
    if pattern == "string_pattern" and dt >= THRESHOLDS["bypass_diode_dt"]:
        return DefectClass.BYPASS_DIODE, _iec_class(dt)

    if pattern == "bottom_row_pattern" and dt >= THRESHOLDS["pid_bottom_dt"]:
        return DefectClass.PID, _iec_class(dt)

    if pattern == "linear_pattern" and dt >= THRESHOLDS["cell_crack_dt"]:
        return DefectClass.CELL_CRACK, _iec_class(dt)

    # 3) 점상 핫스팟의 ΔT 기반
    if dt >= THRESHOLDS["single_cell_hs_dt"]:
        return DefectClass.SINGLE_CELL_HS, _iec_class(dt)
    if dt >= THRESHOLDS["multi_cell_hs_dt"]:
        return DefectClass.MULTI_CELL_HS, _iec_class(dt)

    # 4) J-box 위치 추정 (패널 상단 모서리) + 고온
    if dt >= THRESHOLDS["junction_box_dt"]:
        rel_y = ((hotspot_bbox.y1 + hotspot_bbox.y2) / 2 -
                 panel.bbox_ir.y1) / max(1e-3, panel.bbox_ir.y2 - panel.bbox_ir.y1)
        if rel_y < 0.15:
            return DefectClass.JUNCTION_BOX, _iec_class(dt)

    return DefectClass.UNKNOWN, _iec_class(dt)
