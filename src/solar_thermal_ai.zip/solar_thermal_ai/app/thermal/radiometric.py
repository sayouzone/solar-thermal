"""Radiometric 열화상 처리.

DJI M3T/H20T, FLIR Zenmuse 계열에서 추출된 R-JPEG 또는 16-bit TIFF를
실제 온도(°C)로 변환하고, 패널 단위 ΔT를 계산한다.

DJI의 경우 Thermal SDK(dji_thermal_sdk) 또는 exiftool + 변환 공식 사용.
여기서는 이미 온도 배열(float32, °C)로 디코딩되었다고 가정하는 clean interface를
제공하고, 필요 시 raw → temperature 변환 유틸을 포함한다.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

from app.schemas.models import BBox, ThermalStats


@dataclass
class RadiometricParams:
    """환경/측정 파라미터. EXIF 또는 비행 메타데이터에서 주입."""
    emissivity: float = 0.95        # c-Si 모듈 일반값
    reflected_temp_c: float = 25.0
    atmospheric_temp_c: float = 25.0
    relative_humidity: float = 50.0
    distance_m: float = 30.0


def decode_dji_rjpeg(rjpeg_path: Path,
                     params: RadiometricParams) -> np.ndarray:
    """DJI R-JPEG → float32 °C 배열.

    운영 환경에서는 `dji_thermal_sdk`의 `dirp_measure_ex`를 호출한다.
    SDK 미탑재 빌드에서는 16-bit raw TIFF 경로 사용을 권장.
    """
    try:
        from dji_thermal_sdk.dji_sdk import dirp_create_from_rjpeg, dirp_measure_ex  # type: ignore
    except ImportError as e:
        raise RuntimeError(
            "dji_thermal_sdk not installed. Use 16-bit TIFF path or install SDK."
        ) from e

    handle = dirp_create_from_rjpeg(str(rjpeg_path))
    # SDK call returns temperature matrix in centi-degrees
    temp_matrix = dirp_measure_ex(handle, params.__dict__)
    return (temp_matrix.astype(np.float32) / 10.0)


def load_radiometric_tiff(tiff_path: Path,
                          scale: float = 0.04,
                          offset: float = -273.15) -> np.ndarray:
    """16-bit radiometric TIFF (FLIR convention) → °C.

    기본값은 FLIR raw16 → Kelvin·0.04 → °C. 카메라별 override 필요.
    """
    img = cv2.imread(str(tiff_path), cv2.IMREAD_UNCHANGED)
    if img is None:
        raise FileNotFoundError(tiff_path)
    if img.dtype != np.uint16:
        raise ValueError(f"Expected uint16 radiometric, got {img.dtype}")
    return img.astype(np.float32) * scale + offset


def temperature_to_display(temp_c: np.ndarray,
                           vmin: Optional[float] = None,
                           vmax: Optional[float] = None,
                           colormap: int = cv2.COLORMAP_INFERNO) -> np.ndarray:
    """온도 배열을 시각화용 BGR 이미지로."""
    lo = np.percentile(temp_c, 2) if vmin is None else vmin
    hi = np.percentile(temp_c, 98) if vmax is None else vmax
    norm = np.clip((temp_c - lo) / max(1e-6, hi - lo), 0, 1)
    u8 = (norm * 255).astype(np.uint8)
    return cv2.applyColorMap(u8, colormap)


def compute_panel_stats(temp_c: np.ndarray, panel_bbox: BBox) -> ThermalStats:
    """패널 영역 전체의 통계 — ΔT 기준선 산출."""
    x1, y1, x2, y2 = (int(panel_bbox.x1), int(panel_bbox.y1),
                      int(panel_bbox.x2), int(panel_bbox.y2))
    roi = temp_c[y1:y2, x1:x2]
    if roi.size == 0:
        raise ValueError("Empty panel ROI")
    return ThermalStats(
        t_mean_c=float(roi.mean()),
        t_max_c=float(roi.max()),
        t_min_c=float(roi.min()),
        t_p95_c=float(np.percentile(roi, 95)),
        delta_t_c=0.0,
        panel_ref_c=float(np.median(roi)),
    )


def compute_hotspot_stats(temp_c: np.ndarray,
                          hotspot_bbox: BBox,
                          panel_ref_c: float) -> ThermalStats:
    """핫스팟 ROI 통계 + ΔT 계산.

    ΔT = hotspot 95-percentile − 패널 본체 중앙값 (IEC TS 62446-3 권고).
    """
    x1, y1, x2, y2 = (int(hotspot_bbox.x1), int(hotspot_bbox.y1),
                      int(hotspot_bbox.x2), int(hotspot_bbox.y2))
    roi = temp_c[y1:y2, x1:x2]
    if roi.size == 0:
        raise ValueError("Empty hotspot ROI")
    t_p95 = float(np.percentile(roi, 95))
    return ThermalStats(
        t_mean_c=float(roi.mean()),
        t_max_c=float(roi.max()),
        t_min_c=float(roi.min()),
        t_p95_c=t_p95,
        delta_t_c=t_p95 - panel_ref_c,
        panel_ref_c=panel_ref_c,
    )
