"""파이프라인 오케스트레이터.

FastAPI가 이 객체를 singleton으로 보유하고, 각 요청마다 `.process()`를 호출.
단계별 latency를 기록하여 병목 파악에 사용.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

import numpy as np

from app.detectors.detectors import (
    HotspotDetector, PanelDetector, assign_hotspots_to_panels,
    make_hotspot_id, make_panel_id,
)
from app.fusion.registration import (
    register, transform_bbox, warp_rgb_to_ir,
)
from app.schemas.models import (
    BBox, DefectReport, HotspotDetection, InspectionResult, PanelDetection,
)
from app.thermal.classifier import classify_hotspot
from app.thermal.radiometric import (
    compute_hotspot_stats, compute_panel_stats, temperature_to_display,
)
from app.vlm.analyzer import VLMAnalyzer


@dataclass
class PipelineConfig:
    vlm_min_delta_t: float = 3.0        # 이보다 낮은 ΔT는 VLM 호출 skip
    vlm_max_concurrent: int = 4         # VLM 호출 동시성 (비용 제어)
    min_panel_overlap: float = 0.1


class Pipeline:
    def __init__(self,
                 panel_detector: PanelDetector,
                 hotspot_detector: HotspotDetector,
                 vlm: VLMAnalyzer,
                 config: PipelineConfig | None = None):
        self.panel_detector = panel_detector
        self.hotspot_detector = hotspot_detector
        self.vlm = vlm
        self.cfg = config or PipelineConfig()

    def process(self,
                rgb_bgr: np.ndarray,
                temp_c: np.ndarray,
                frame_id: Optional[str] = None,
                geo: Optional[dict] = None,
                preset_H: Optional[np.ndarray] = None) -> InspectionResult:
        t0 = time.perf_counter()
        timings: dict[str, float] = {}
        frame_id = frame_id or f"frame_{uuid.uuid4().hex[:8]}"

        # 1) RGB → IR 정합
        t = time.perf_counter()
        reg = register(rgb_bgr, temp_c, preset_H=preset_H)
        rgb_warped = warp_rgb_to_ir(rgb_bgr, reg)
        timings["registration_ms"] = (time.perf_counter() - t) * 1000

        # 2) 패널 검출 (정합된 RGB 사용 → IR 좌표계로 바로 나옴)
        t = time.perf_counter()
        panel_raw = self.panel_detector.detect(rgb_warped)
        panels: list[PanelDetection] = []
        for bbox, orientation in panel_raw:
            pid = make_panel_id()
            panels.append(PanelDetection(
                panel_id=pid,
                bbox_rgb=bbox,           # 이미 IR 좌표계
                bbox_ir=bbox,
                orientation_deg=orientation,
            ))
        timings["panel_detect_ms"] = (time.perf_counter() - t) * 1000

        # 3) 핫스팟 검출 (IR)
        t = time.perf_counter()
        hotspot_bboxes = self.hotspot_detector.detect(temp_c)
        timings["hotspot_detect_ms"] = (time.perf_counter() - t) * 1000

        # 4) 핫스팟 ↔ 패널 매칭 및 thermal stats 계산
        t = time.perf_counter()
        hs_to_panel = assign_hotspots_to_panels(hotspot_bboxes, panels)
        panel_stats_cache: dict[str, float] = {}
        for p in panels:
            panel_stats_cache[p.panel_id] = compute_panel_stats(
                temp_c, p.bbox_ir).panel_ref_c

        hotspots: list[HotspotDetection] = []
        for idx, bb in enumerate(hotspot_bboxes):
            pid = hs_to_panel.get(idx)
            panel = next((p for p in panels if p.panel_id == pid), None)
            ref_c = panel_stats_cache.get(pid) if pid else float(np.median(temp_c))
            thermal = compute_hotspot_stats(temp_c, bb, panel_ref_c=ref_c)
            candidate, iec = (classify_hotspot(bb, thermal, panel)
                              if panel else (None, None))
            hotspots.append(HotspotDetection(
                hotspot_id=make_hotspot_id(),
                bbox_ir=bb,
                parent_panel_id=pid,
                thermal=thermal,
                candidate_class=candidate or thermal_default_class(thermal),
                iec_class=iec,
            ))
        timings["thermal_ms"] = (time.perf_counter() - t) * 1000

        # 5) VLM 분석 — 유의미한 ΔT만
        t = time.perf_counter()
        ir_display = temperature_to_display(temp_c)
        reports: list[DefectReport] = []
        confirmed = 0

        for hs in hotspots:
            if abs(hs.thermal.delta_t_c) < self.cfg.vlm_min_delta_t:
                continue
            panel = next(
                (p for p in panels if p.panel_id == hs.parent_panel_id), None)
            verdict = self.vlm.analyze_hotspot(rgb_warped, ir_display, hs, panel)
            if verdict.is_actual_defect:
                confirmed += 1
            reports.append(DefectReport(hotspot=hs, verdict=verdict, geo=geo))
        timings["vlm_ms"] = (time.perf_counter() - t) * 1000

        timings["total_ms"] = (time.perf_counter() - t0) * 1000

        return InspectionResult(
            job_id=uuid.uuid4().hex,
            frame_id=frame_id,
            timestamp=datetime.now(timezone.utc).isoformat(),
            num_panels=len(panels),
            num_hotspots=len(hotspots),
            num_confirmed_defects=confirmed,
            defects=reports,
            processing_ms=timings,
        )


def thermal_default_class(thermal):
    """핫스팟이 어떤 패널에도 속하지 않을 때 fallback 분류."""
    from app.schemas.models import DefectClass
    if thermal.delta_t_c >= 20:
        return DefectClass.SINGLE_CELL_HS
    if thermal.delta_t_c >= 10:
        return DefectClass.MULTI_CELL_HS
    return DefectClass.UNKNOWN
