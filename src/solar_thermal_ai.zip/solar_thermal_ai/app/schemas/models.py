"""데이터 스키마 정의 — 파이프라인 전체에서 공유되는 Pydantic 모델."""
from __future__ import annotations

from enum import Enum
from typing import Literal, Optional

from pydantic import BaseModel, Field


class DefectClass(str, Enum):
    SINGLE_CELL_HS = "single_cell_hotspot"
    MULTI_CELL_HS = "multi_cell_hotspot"
    BYPASS_DIODE = "bypass_diode_failure"
    PID = "potential_induced_degradation"
    SOILING = "soiling"
    CELL_CRACK = "cell_crack"
    JUNCTION_BOX = "junction_box_overheat"
    SHADING = "shading"  # 결함 아님 — VLM으로 필터링
    UNKNOWN = "unknown"


class Severity(str, Enum):
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class BBox(BaseModel):
    """XYXY 픽셀 좌표 (IR 기준)."""
    x1: float
    y1: float
    x2: float
    y2: float
    score: float = Field(..., ge=0.0, le=1.0)

    def area(self) -> float:
        return max(0.0, (self.x2 - self.x1) * (self.y2 - self.y1))


class PanelDetection(BaseModel):
    """RGB에서 검출된 패널. 좌표는 IR 좌표계로 정합된 값."""
    panel_id: str
    bbox_rgb: BBox
    bbox_ir: BBox  # 호모그래피 적용 후
    orientation_deg: float = 0.0


class ThermalStats(BaseModel):
    t_mean_c: float
    t_max_c: float
    t_min_c: float
    t_p95_c: float
    delta_t_c: float  # hotspot - panel_ref
    panel_ref_c: float  # 해당 패널 본체 중앙값


class HotspotDetection(BaseModel):
    hotspot_id: str
    bbox_ir: BBox
    parent_panel_id: Optional[str] = None
    thermal: ThermalStats
    candidate_class: DefectClass = DefectClass.UNKNOWN
    iec_class: Optional[Literal["Class_A", "Class_B", "Class_C"]] = None


class VLMVerdict(BaseModel):
    """VLM이 RGB+IR 크롭을 보고 내린 최종 판정."""
    confirmed_class: DefectClass
    is_actual_defect: bool  # shading/reflection 등 false positive 필터
    severity: Severity
    root_cause: str
    recommended_action: str
    confidence: float = Field(..., ge=0.0, le=1.0)
    evidence_notes: str


class DefectReport(BaseModel):
    hotspot: HotspotDetection
    verdict: VLMVerdict
    geo: Optional[dict] = None  # {lat, lon, alt, heading} — EXIF/telemetry에서


class InspectionResult(BaseModel):
    job_id: str
    frame_id: str
    timestamp: str
    num_panels: int
    num_hotspots: int
    num_confirmed_defects: int
    defects: list[DefectReport]
    processing_ms: dict[str, float]  # 단계별 latency
