"""FastAPI 서빙 레이어.

엔드포인트:
- POST /inspect/frame   — 단일 프레임 (RGB + radiometric TIFF) 분석
- POST /inspect/batch   — 배치 (S3 URI list) 비동기 작업 생성
- GET  /inspect/jobs/{id} — 배치 작업 결과 조회
- GET  /health

주의:
- 클라우드 배포 시 YOLO/VLM 모델은 컨테이너 시작 시 lazy-load.
- GPU 메모리 최소 16GB 권장 (YOLOv12-L 두 개 + VLM client).
- 배치 엔드포인트는 Celery/Arq/Temporal 같은 워커 큐와 연결.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import cv2
import numpy as np
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from app.core.pipeline import Pipeline, PipelineConfig
from app.detectors.detectors import (
    HotspotDetector, HotspotDetectorConfig,
    PanelDetector, PanelDetectorConfig,
)
from app.schemas.models import InspectionResult
from app.thermal.radiometric import load_radiometric_tiff
from app.vlm.analyzer import AnthropicVLM, VLMAnalyzer


app = FastAPI(title="Solar Thermal AI", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


_pipeline: Optional[Pipeline] = None


def get_pipeline() -> Pipeline:
    global _pipeline
    if _pipeline is not None:
        return _pipeline

    weights_dir = Path(os.environ.get("WEIGHTS_DIR", "/models"))
    device = os.environ.get("DEVICE", "cuda:0")

    panel_det = PanelDetector(PanelDetectorConfig(
        weights=weights_dir / "yolov12_panel.pt",
        device=device,
    ))
    hotspot_det = HotspotDetector(HotspotDetectorConfig(
        weights=weights_dir / "yolov12_hotspot.pt",
        device=device,
    ))
    vlm_backend = AnthropicVLM(
        model=os.environ.get("VLM_MODEL", "claude-sonnet-4-5"),
    )
    vlm = VLMAnalyzer(vlm_backend)

    _pipeline = Pipeline(panel_det, hotspot_det, vlm, PipelineConfig())
    return _pipeline


@app.get("/health")
def health():
    return {"status": "ok"}


def _read_image_upload(upload: UploadFile) -> np.ndarray:
    data = upload.file.read()
    arr = np.frombuffer(data, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise HTTPException(400, f"Cannot decode image: {upload.filename}")
    return img


def _read_radiometric_upload(upload: UploadFile, tmp_dir: Path) -> np.ndarray:
    tmp_dir.mkdir(parents=True, exist_ok=True)
    dst = tmp_dir / upload.filename
    with open(dst, "wb") as f:
        f.write(upload.file.read())
    return load_radiometric_tiff(dst)


@app.post("/inspect/frame", response_model=InspectionResult)
async def inspect_frame(
    rgb: UploadFile = File(..., description="RGB image (JPEG/PNG)"),
    ir: UploadFile = File(..., description="Radiometric 16-bit TIFF (or R-JPEG)"),
    frame_id: Optional[str] = Form(None),
    latitude: Optional[float] = Form(None),
    longitude: Optional[float] = Form(None),
    altitude_m: Optional[float] = Form(None),
    heading_deg: Optional[float] = Form(None),
) -> InspectionResult:
    rgb_bgr = _read_image_upload(rgb)
    temp_c = _read_radiometric_upload(ir, Path("/tmp/solar_ai"))

    geo = None
    if latitude is not None and longitude is not None:
        geo = {"lat": latitude, "lon": longitude,
               "alt": altitude_m, "heading": heading_deg}

    pipeline = get_pipeline()
    return pipeline.process(rgb_bgr, temp_c, frame_id=frame_id, geo=geo)
