"""YOLO 기반 검출기 — 패널(RGB) / 핫스팟(IR).

실제 프로덕션에서는 ultralytics YOLOv12 또는 RF-DETR으로 학습한 가중치를 사용.
여기서는 ultralytics API를 감싸는 얇은 어댑터를 제공하고, 주입식(Injection)
인터페이스로 설계해 단위 테스트 시 mock 교체가 쉽게 했다.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

import numpy as np

from app.schemas.models import BBox, PanelDetection


class YOLOLike(Protocol):
    """ultralytics.YOLO 호환 최소 인터페이스 (테스트 mock을 위해)."""
    def predict(self, source, conf: float, iou: float, verbose: bool, device): ...


def _load_ultralytics(weights_path: Path, device: str = "cuda:0"):
    from ultralytics import YOLO  # lazy import
    model = YOLO(str(weights_path))
    model.to(device)
    return model


@dataclass
class PanelDetectorConfig:
    weights: Path
    conf: float = 0.35
    iou: float = 0.5
    device: str = "cuda:0"
    min_panel_area: int = 2000  # 픽셀


class PanelDetector:
    """RGB 기반 태양광 패널 인스턴스 검출."""

    def __init__(self, config: PanelDetectorConfig, model: YOLOLike | None = None):
        self.cfg = config
        self.model = model or _load_ultralytics(config.weights, config.device)

    def detect(self, rgb_bgr: np.ndarray) -> list[tuple[BBox, float]]:
        """→ [(bbox_rgb, orientation_deg), ...]"""
        results = self.model.predict(
            source=rgb_bgr,
            conf=self.cfg.conf,
            iou=self.cfg.iou,
            verbose=False,
            device=self.cfg.device,
        )
        out: list[tuple[BBox, float]] = []
        if not results:
            return out
        r = results[0]
        boxes = getattr(r, "boxes", None)
        if boxes is None:
            return out
        xyxy = boxes.xyxy.cpu().numpy()
        confs = boxes.conf.cpu().numpy()
        for (x1, y1, x2, y2), c in zip(xyxy, confs):
            bb = BBox(x1=float(x1), y1=float(y1),
                      x2=float(x2), y2=float(y2), score=float(c))
            if bb.area() < self.cfg.min_panel_area:
                continue
            out.append((bb, 0.0))  # orientation은 별도 OBB 모델 사용 시 채움
        return out


@dataclass
class HotspotDetectorConfig:
    weights: Path
    conf: float = 0.25      # 재현율 우선 — 이후 thermal + VLM로 필터
    iou: float = 0.45
    device: str = "cuda:0"
    min_hotspot_area: int = 20


class HotspotDetector:
    """IR(thermal) 기반 핫스팟 검출.

    입력은 (H,W) float32 °C 배열. 내부에서 8-bit 시각화로 변환 후 YOLO 호출.
    """

    def __init__(self, config: HotspotDetectorConfig, model: YOLOLike | None = None):
        self.cfg = config
        self.model = model or _load_ultralytics(config.weights, config.device)

    @staticmethod
    def _to_3ch(temp_c: np.ndarray) -> np.ndarray:
        """온도 배열을 YOLO 입력용 3채널 uint8로 정규화."""
        lo = np.percentile(temp_c, 2)
        hi = np.percentile(temp_c, 98)
        norm = np.clip((temp_c - lo) / max(1e-6, hi - lo), 0, 1)
        u8 = (norm * 255).astype(np.uint8)
        return np.stack([u8, u8, u8], axis=-1)

    def detect(self, temp_c: np.ndarray) -> list[BBox]:
        image = self._to_3ch(temp_c)
        results = self.model.predict(
            source=image,
            conf=self.cfg.conf,
            iou=self.cfg.iou,
            verbose=False,
            device=self.cfg.device,
        )
        out: list[BBox] = []
        if not results:
            return out
        r = results[0]
        boxes = getattr(r, "boxes", None)
        if boxes is None:
            return out
        xyxy = boxes.xyxy.cpu().numpy()
        confs = boxes.conf.cpu().numpy()
        for (x1, y1, x2, y2), c in zip(xyxy, confs):
            bb = BBox(x1=float(x1), y1=float(y1),
                      x2=float(x2), y2=float(y2), score=float(c))
            if bb.area() < self.cfg.min_hotspot_area:
                continue
            out.append(bb)
        return out


def assign_hotspots_to_panels(hotspots: list[BBox],
                              panels: list[PanelDetection]) -> dict[int, str]:
    """핫스팟 index → 소속 panel_id. IoU 최대 매칭.

    핫스팟은 패널 내부에 있어야 의미 있음. 매칭 실패 시 무시.
    """
    mapping: dict[int, str] = {}
    for i, hs in enumerate(hotspots):
        best_iou, best_pid = 0.0, None
        for p in panels:
            iou = _bbox_iou(hs, p.bbox_ir)
            if iou > best_iou:
                best_iou, best_pid = iou, p.panel_id
        if best_iou > 0.1 and best_pid is not None:
            mapping[i] = best_pid
    return mapping


def _bbox_iou(a: BBox, b: BBox) -> float:
    xA = max(a.x1, b.x1); yA = max(a.y1, b.y1)
    xB = min(a.x2, b.x2); yB = min(a.y2, b.y2)
    inter = max(0.0, xB - xA) * max(0.0, yB - yA)
    if inter == 0:
        return 0.0
    return inter / (a.area() + b.area() - inter + 1e-9)


def make_panel_id() -> str:
    return f"panel_{uuid.uuid4().hex[:8]}"


def make_hotspot_id() -> str:
    return f"hs_{uuid.uuid4().hex[:8]}"
