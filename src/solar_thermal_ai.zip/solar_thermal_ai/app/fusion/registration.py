"""RGB ↔ IR 영상 정합 (Registration).

RGB와 IR는 해상도/FOV/센서가 다르므로 같은 좌표계로 정합해야
YOLO 검출 결과와 ΔT 계산이 정확해진다.

전략:
1) 카메라 보정값(homography)이 프리셋으로 있으면 그것을 우선 사용 (DJI M3T
   등은 캘리브레이션 파라미터 제공).
2) 없으면 ECC (Enhanced Correlation Coefficient) 기반 refinement.
3) ECC 실패 시 ORB/SIFT feature matching fallback.

출력은 RGB 좌표계 → IR 좌표계 homography (3x3).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np


@dataclass
class RegistrationResult:
    H_rgb_to_ir: np.ndarray  # 3x3
    method: str              # 'preset' | 'ecc' | 'feature' | 'identity'
    inlier_ratio: float
    warped_rgb_shape: tuple[int, int]  # (H, W)


def _ir_preprocess(ir_temp_c: np.ndarray) -> np.ndarray:
    """온도 배열을 feature-friendly 8-bit grayscale로 변환."""
    lo = np.percentile(ir_temp_c, 2)
    hi = np.percentile(ir_temp_c, 98)
    norm = np.clip((ir_temp_c - lo) / max(1e-6, hi - lo), 0, 1)
    gray = (norm * 255).astype(np.uint8)
    return cv2.equalizeHist(gray)


def _rgb_preprocess(rgb_bgr: np.ndarray, target_shape: tuple[int, int]) -> np.ndarray:
    """RGB를 IR 해상도로 리사이즈 + grayscale + CLAHE."""
    gray = cv2.cvtColor(rgb_bgr, cv2.COLOR_BGR2GRAY)
    h, w = target_shape
    resized = cv2.resize(gray, (w, h), interpolation=cv2.INTER_AREA)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    return clahe.apply(resized)


def register_ecc(rgb_bgr: np.ndarray,
                 ir_temp_c: np.ndarray,
                 max_iter: int = 200,
                 eps: float = 1e-6) -> Optional[np.ndarray]:
    """ECC 기반 homography 추정. 실패 시 None."""
    ir_gray = _ir_preprocess(ir_temp_c)
    rgb_gray = _rgb_preprocess(rgb_bgr, ir_gray.shape)

    warp = np.eye(3, 3, dtype=np.float32)
    criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, max_iter, eps)
    try:
        _, warp = cv2.findTransformECC(
            templateImage=ir_gray,
            inputImage=rgb_gray,
            warpMatrix=warp,
            motionType=cv2.MOTION_HOMOGRAPHY,
            criteria=criteria,
        )
        return warp
    except cv2.error:
        return None


def register_feature(rgb_bgr: np.ndarray,
                     ir_temp_c: np.ndarray,
                     min_matches: int = 25) -> tuple[Optional[np.ndarray], float]:
    """ORB feature matching fallback."""
    ir_gray = _ir_preprocess(ir_temp_c)
    rgb_gray = _rgb_preprocess(rgb_bgr, ir_gray.shape)

    orb = cv2.ORB_create(nfeatures=3000)
    kp1, des1 = orb.detectAndCompute(rgb_gray, None)
    kp2, des2 = orb.detectAndCompute(ir_gray, None)
    if des1 is None or des2 is None or len(kp1) < min_matches or len(kp2) < min_matches:
        return None, 0.0

    matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = sorted(matcher.match(des1, des2), key=lambda m: m.distance)
    if len(matches) < min_matches:
        return None, 0.0

    src = np.float32([kp1[m.queryIdx].pt for m in matches]).reshape(-1, 1, 2)
    dst = np.float32([kp2[m.trainIdx].pt for m in matches]).reshape(-1, 1, 2)
    H, mask = cv2.findHomography(src, dst, cv2.RANSAC, 3.0)
    if H is None:
        return None, 0.0
    inlier_ratio = float(mask.sum()) / len(mask)
    return H, inlier_ratio


def register(rgb_bgr: np.ndarray,
             ir_temp_c: np.ndarray,
             preset_H: Optional[np.ndarray] = None) -> RegistrationResult:
    """정합 총괄. preset → ECC → feature fallback 순."""
    ir_h, ir_w = ir_temp_c.shape[:2]

    if preset_H is not None:
        return RegistrationResult(
            H_rgb_to_ir=preset_H.astype(np.float32),
            method="preset",
            inlier_ratio=1.0,
            warped_rgb_shape=(ir_h, ir_w),
        )

    H = register_ecc(rgb_bgr, ir_temp_c)
    if H is not None:
        return RegistrationResult(
            H_rgb_to_ir=H, method="ecc", inlier_ratio=1.0,
            warped_rgb_shape=(ir_h, ir_w),
        )

    H, inlier_ratio = register_feature(rgb_bgr, ir_temp_c)
    if H is not None:
        return RegistrationResult(
            H_rgb_to_ir=H.astype(np.float32), method="feature",
            inlier_ratio=inlier_ratio, warped_rgb_shape=(ir_h, ir_w),
        )

    # 마지막 안전장치 — identity + scale
    sx = ir_w / rgb_bgr.shape[1]
    sy = ir_h / rgb_bgr.shape[0]
    H_id = np.array([[sx, 0, 0], [0, sy, 0], [0, 0, 1]], dtype=np.float32)
    return RegistrationResult(
        H_rgb_to_ir=H_id, method="identity", inlier_ratio=0.0,
        warped_rgb_shape=(ir_h, ir_w),
    )


def warp_rgb_to_ir(rgb_bgr: np.ndarray, result: RegistrationResult) -> np.ndarray:
    h, w = result.warped_rgb_shape
    return cv2.warpPerspective(rgb_bgr, result.H_rgb_to_ir, (w, h))


def transform_bbox(bbox_xyxy: tuple[float, float, float, float],
                   H: np.ndarray) -> tuple[float, float, float, float]:
    """RGB 좌표계 bbox → IR 좌표계."""
    x1, y1, x2, y2 = bbox_xyxy
    corners = np.array([[x1, y1], [x2, y1], [x2, y2], [x1, y2]], dtype=np.float32)
    corners = corners.reshape(-1, 1, 2)
    warped = cv2.perspectiveTransform(corners, H).reshape(-1, 2)
    return (float(warped[:, 0].min()), float(warped[:, 1].min()),
            float(warped[:, 0].max()), float(warped[:, 1].max()))
