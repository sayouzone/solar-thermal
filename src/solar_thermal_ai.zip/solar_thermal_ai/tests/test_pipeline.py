"""단위 테스트 — YOLO/VLM mock 주입."""
from __future__ import annotations

from unittest.mock import MagicMock

import numpy as np
import pytest

from app.core.pipeline import Pipeline, PipelineConfig
from app.detectors.detectors import (
    HotspotDetector, HotspotDetectorConfig,
    PanelDetector, PanelDetectorConfig,
)
from app.schemas.models import BBox, DefectClass, Severity, VLMVerdict
from app.thermal.classifier import classify_hotspot
from app.thermal.radiometric import compute_hotspot_stats, compute_panel_stats


@pytest.fixture
def synthetic_thermal():
    """640x512 패널 배경 25°C + 중앙에 50°C 핫스팟."""
    t = np.full((512, 640), 25.0, dtype=np.float32)
    t[240:270, 300:330] = 50.0  # ΔT≈25°C
    return t


@pytest.fixture
def synthetic_rgb():
    return (np.random.rand(1080, 1440, 3) * 255).astype(np.uint8)


def test_panel_stats(synthetic_thermal):
    panel = BBox(x1=100, y1=100, x2=540, y2=412, score=1.0)
    stats = compute_panel_stats(synthetic_thermal, panel)
    assert 25.0 <= stats.panel_ref_c <= 30.0


def test_hotspot_stats_delta_t(synthetic_thermal):
    hs = BBox(x1=300, y1=240, x2=330, y2=270, score=0.9)
    stats = compute_hotspot_stats(synthetic_thermal, hs, panel_ref_c=25.0)
    assert stats.delta_t_c > 20.0


def test_classifier_single_cell_hotspot(synthetic_thermal):
    from app.schemas.models import PanelDetection
    panel_bbox = BBox(x1=100, y1=100, x2=540, y2=412, score=1.0)
    panel = PanelDetection(panel_id="p1", bbox_rgb=panel_bbox, bbox_ir=panel_bbox)
    hs = BBox(x1=300, y1=240, x2=330, y2=270, score=0.9)
    stats = compute_hotspot_stats(synthetic_thermal, hs, panel_ref_c=25.0)
    cls, iec = classify_hotspot(hs, stats, panel)
    assert cls == DefectClass.SINGLE_CELL_HS
    assert iec == "Class_A"


class _FakeYOLOResult:
    def __init__(self, xyxy, conf):
        class _Boxes:
            def __init__(self, xyxy, conf):
                import torch  # only to mimic .cpu().numpy()
                self.xyxy = torch.tensor(xyxy, dtype=torch.float32)
                self.conf = torch.tensor(conf, dtype=torch.float32)
        self.boxes = _Boxes(xyxy, conf)


def _fake_yolo(xyxy, conf):
    m = MagicMock()
    m.predict.return_value = [_FakeYOLOResult(xyxy, conf)]
    return m


def test_pipeline_end_to_end(monkeypatch, synthetic_thermal, synthetic_rgb):
    torch = pytest.importorskip("torch")  # fake YOLO uses torch tensors
    panel_model = _fake_yolo([[100, 100, 540, 412]], [0.9])
    hotspot_model = _fake_yolo([[300, 240, 330, 270]], [0.85])

    panel_det = PanelDetector(
        PanelDetectorConfig(weights="_unused_"),
        model=panel_model,
    )
    hotspot_det = HotspotDetector(
        HotspotDetectorConfig(weights="_unused_"),
        model=hotspot_model,
    )

    fake_vlm = MagicMock()
    fake_vlm.analyze_hotspot.return_value = VLMVerdict(
        confirmed_class=DefectClass.SINGLE_CELL_HS,
        is_actual_defect=True,
        severity=Severity.HIGH,
        root_cause="Cell-level electrical fault consistent with localized ΔT>20°C.",
        recommended_action="Schedule EL imaging and I-V curve test.",
        confidence=0.88,
        evidence_notes="Point hotspot confined to one cell, no external shading in RGB.",
    )

    pipe = Pipeline(panel_det, hotspot_det, fake_vlm, PipelineConfig())
    result = pipe.process(synthetic_rgb, synthetic_thermal, frame_id="t1")

    assert result.num_panels == 1
    assert result.num_hotspots == 1
    assert result.num_confirmed_defects == 1
    assert result.defects[0].verdict.confirmed_class == DefectClass.SINGLE_CELL_HS
    assert "total_ms" in result.processing_ms
